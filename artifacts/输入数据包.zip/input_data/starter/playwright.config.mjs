export default {
  testDir: "./tests",
  use: { baseURL: "http://127.0.0.1:5190" }
};
