import { test, expect } from "@playwright/test";

test("只验证默认页面", async ({ page }) => {
  await page.goto("/creator_studio.html");
  await page.locator("#validate").click();
  await expect(page.locator("#status-message")).toContainText("素材");
});
