const policy = {
  "fixed_now_utc": "2026-07-30T12:00:00Z",
  "min_schedule_lead_minutes": 180,
  "alt_text_min_chars": 8,
  "downloadable_columns": [
    "case_id",
    "review_state",
    "submit_enabled",
    "status_text",
    "actor_role"
  ],
  "review_states": [
    "ready_to_submit",
    "needs_disclosure",
    "account_limited",
    "schedule_too_soon",
    "needs_alt_text",
    "reviewer_readonly"
  ]
};
const banner = document.querySelector("#actor-banner");
const submit = document.querySelector("[data-testid=submit-asset]");
const download = document.querySelector("[data-testid=download-receipt]");
const stateNode = document.querySelector("[data-testid=review-state]");
const statusNode = document.querySelector("[data-testid=status-message]");
let lastResult = null;
function minutesBetween(startUtc, endUtc) {
  return Math.round((Date.parse(endUtc) - Date.parse(startUtc)) / 60000);
}
function roleInfo() {
  return {
    role: localStorage.getItem("studioRole") || "creator",
    accountStatus: localStorage.getItem("studioAccountStatus") || "verified",
    displayName: localStorage.getItem("studioDisplayName") || "未命名用户",
  };
}
function readForm() {
  return {
    case_id: document.querySelector("#case-id").value.trim(),
    account_status: document.querySelector("#account-status").value,
    asset_type: document.querySelector("#asset-type").value,
    commercial_use: document.querySelector("input[name=commercial]:checked").value,
    disclosure: document.querySelector("#disclosure").value,
    alt_text: document.querySelector("#alt-text").value.trim(),
    schedule_utc: document.querySelector("#schedule-utc").value.trim(),
  };
}
function evaluate(input) {
  const actor = roleInfo();
  let review_state = "ready_to_submit";
  let submit_enabled = true;
  let status_text = "素材可以提交审核";
  const lead = minutesBetween(policy.fixed_now_utc, input.schedule_utc);
  if (actor.role === "reviewer") {
    review_state = "reviewer_readonly";
    submit_enabled = false;
    status_text = "复核员只读预览，导出回执后交还创作者";
  } else if (input.account_status !== "verified" || actor.accountStatus !== "verified") {
    review_state = "account_limited";
    submit_enabled = false;
    status_text = "账号处于限制期，暂不能提交广告素材";
  } else if (input.commercial_use === "true" && input.disclosure === "none") {
    review_state = "needs_disclosure";
    submit_enabled = false;
    status_text = "商业合作必须选择广告披露";
  } else if (input.asset_type === "image_carousel" && input.alt_text.length < policy.alt_text_min_chars) {
    review_state = "needs_alt_text";
    submit_enabled = false;
    status_text = "图文轮播需要填写至少8个字的替代文本";
  } else if (lead < policy.min_schedule_lead_minutes) {
    review_state = "schedule_too_soon";
    submit_enabled = false;
    status_text = "排期至少要提前180分钟";
  }
  return { ...input, actor_role: actor.role, review_state, submit_enabled, status_text, lead_minutes: lead };
}
function toCsv(rows) {
  const header = policy.downloadable_columns.join(",");
  const body = rows.map((row) => policy.downloadable_columns.map((key) => JSON.stringify(String(row[key] ?? ""))).join(",")).join("\n");
  return header + "\n" + body + "\n";
}
document.querySelector("#validate").addEventListener("click", () => {
  lastResult = evaluate(readForm());
  stateNode.textContent = lastResult.review_state;
  statusNode.textContent = lastResult.status_text;
  submit.disabled = !lastResult.submit_enabled;
  download.disabled = false;
});
download.addEventListener("click", () => {
  if (!lastResult) return;
  const rows = [lastResult];
  if (lastResult.actor_role === "reviewer") {
    rows.push({ ...lastResult, review_state: "handoff_required", status_text: "需要创作者确认后提交" });
    rows.push({ ...lastResult, review_state: "audit_note_saved", status_text: "复核备注已保存" });
  }
  const blob = new Blob([toCsv(rows)], { type: "text/csv;charset=utf-8" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `${lastResult.case_id}_submission_receipt.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
});
const actor = roleInfo();
banner.textContent = actor.displayName;
