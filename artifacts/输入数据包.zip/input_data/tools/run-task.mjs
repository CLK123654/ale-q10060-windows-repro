import { spawn } from "node:child_process";
import path from "node:path";
import process from "node:process";

const inputRoot = path.resolve(process.cwd());
const outputRoot = path.join(inputRoot, "output");

const npx = process.platform === "win32" ? "npx.cmd" : "npx";
const command = process.platform === "win32" ? (process.env.ComSpec ?? "cmd.exe") : npx;
const args = process.platform === "win32"
  ? ["/d", "/s", "/c", npx, "playwright", "test", "--config=output/playwright.config.mjs"]
  : ["playwright", "test", "--config=output/playwright.config.mjs"];
const child = spawn(command, args, {
  cwd: inputRoot,
  env: { ...process.env, ALE_INPUT_ROOT: inputRoot, ALE_OUTPUT_ROOT: outputRoot },
  stdio: "inherit",
  windowsHide: true,
});

const exitCode = await new Promise((resolve, reject) => {
  child.once("error", reject);
  child.once("exit", (code) => resolve(code ?? 1));
});

process.exitCode = exitCode;
